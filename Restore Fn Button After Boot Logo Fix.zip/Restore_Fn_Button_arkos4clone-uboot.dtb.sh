#!/bin/bash

echo "Restoring Fn Button..."
systemctl stop ogage
[[ ! -f "/usr/local/bin/ogage.bak" ]] && cp /usr/local/bin/ogage /usr/local/bin/ogage.bak
cp /ogage/ogage_arkos4clone /usr/local/bin/ogage
chmod +x /usr/local/bin/ogage
systemctl start ogage

echo "Done!"
sleep 2